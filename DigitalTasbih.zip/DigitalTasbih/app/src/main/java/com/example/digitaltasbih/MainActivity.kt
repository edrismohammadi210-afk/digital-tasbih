package com.example.digitaltasbih

import android.app.Activity
import android.os.Bundle
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("tasbih_prefs", Context.MODE_PRIVATE) }
    private var count = 0
    private var target = 33
    private var vibrationEnabled = true
    private lateinit var countView: TextView
    private lateinit var targetView: TextView
    private lateinit var vibrationButton: Button

    private val green = Color.rgb(16, 37, 30)
    private val gold = Color.rgb(212, 175, 55)
    private val cream = Color.rgb(250, 247, 238)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        count = prefs.getInt("count", 0)
        target = prefs.getInt("target", 33)
        vibrationEnabled = prefs.getBoolean("vibration", true)
        buildUi()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(green)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "📿 تسبیح دیجیتال"
            textSize = 28f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())
        root.addView(space(18))

        targetView = TextView(this).apply {
            textSize = 16f
            setTextColor(cream)
            gravity = Gravity.CENTER
        }
        root.addView(targetView, matchWrap())
        root.addView(space(18))

        val counterPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(28), dp(24), dp(28))
            background = rounded(Color.rgb(25, 55, 44), 28)
        }
        countView = TextView(this).apply {
            text = "0"
            textSize = 58f
            typeface = Typeface.MONOSPACE
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(cream)
            gravity = Gravity.CENTER
        }
        counterPanel.addView(countView, matchWrap())
        val caption = TextView(this).apply {
            text = "ذکرهای انجام‌شده"
            textSize = 15f
            setTextColor(gold)
            gravity = Gravity.CENTER
        }
        counterPanel.addView(caption, matchWrap())
        root.addView(counterPanel, LinearLayout.LayoutParams(-1, dp(170)))
        root.addView(space(24))

        val countButton = Button(this).apply {
            text = "ذکر بعدی  +1"
            textSize = 21f
            setTextColor(green)
            background = rounded(gold, 24)
            isAllCaps = false
            setOnClickListener {
                count++
                save()
                refresh()
                vibrate()
                if (count == target) Toast.makeText(this@MainActivity, "آفرین! به هدف رسیدی.", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(countButton, LinearLayout.LayoutParams(-1, dp(68)))
        root.addView(space(14))

        val targetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        targetRow.addView(makeSmallButton("هدف ۳۳") { setTarget(33) }, weighted())
        targetRow.addView(makeSmallButton("هدف ۹۹") { setTarget(99) }, weighted())
        targetRow.addView(makeSmallButton("هدف ۱۰۰۰") { setTarget(1000) }, weighted())
        root.addView(targetRow, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(space(10))

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        actionRow.addView(makeSmallButton("صفر کردن") {
            count = 0
            save()
            refresh()
        }, weighted())
        vibrationButton = makeSmallButton("لرزش: روشن") {
            vibrationEnabled = !vibrationEnabled
            prefs.edit().putBoolean("vibration", vibrationEnabled).apply()
            refresh()
        }
        actionRow.addView(vibrationButton, weighted())
        root.addView(actionRow, LinearLayout.LayoutParams(-1, dp(52)))

        val note = TextView(this).apply {
            text = "شمارش به‌صورت خودکار در گوشی ذخیره می‌شود."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(space(18))
        root.addView(note, matchWrap())
        setContentView(root)
    }

    private fun setTarget(value: Int) {
        target = value
        prefs.edit().putInt("target", target).apply()
        refresh()
    }

    private fun refresh() {
        countView.text = count.toString()
        targetView.text = "هدف: $target   •   باقی‌مانده: ${(target - count).coerceAtLeast(0)}"
        vibrationButton.text = if (vibrationEnabled) "لرزش: روشن" else "لرزش: خاموش"
    }

    private fun save() { prefs.edit().putInt("count", count).putInt("target", target).apply() }

    private fun vibrate() {
        if (!vibrationEnabled) return
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                getSystemService(VibratorManager::class.java).defaultVibrator
            } else {
                @Suppress("DEPRECATION") getSystemService(VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) vibrator.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") vibrator.vibrate(25)
        } catch (_: Exception) { /* Vibration is optional on devices without a vibrator. */ }
    }

    private fun makeSmallButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 13f
        isAllCaps = false
        setTextColor(cream)
        background = rounded(Color.rgb(37, 69, 56), 14)
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun weighted() = LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
